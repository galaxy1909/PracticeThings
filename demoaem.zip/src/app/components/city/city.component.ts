import { Component, OnInit } from '@angular/core';
import { CitysService } from 'src/app/services/citys.service';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-city',
  templateUrl: './city.component.html',
  styleUrls: ['./city.component.css']
})
export class CityComponent implements OnInit {
  
  cities:any;
  currentCity:any;
  currentIndex = -1;
city={
  cityname:''
};
submitted=false;
  constructor(private citysService:CitysService,
    private route:ActivatedRoute,
    private router:Router) { }

  ngOnInit(): void {
    this.retrieveCities();
  }

  retrieveCities():void{
    this.citysService.getAll().subscribe(
      data => {
        this.cities=data;
        console.log(data);
      },
      error => {
        console.log(error);
      });
  }

  saveCity():void{
   const data={
      cityname:this.city.cityname
    };
    this.citysService.create(data).subscribe(
      response => {
        console.log(response);
        this.submitted=true;
      },
      error =>
      {
        console.log(error);
      });

  }

  newCity(): void{
    this.submitted=false;
    this.city={
      cityname:''
    };
  }

  setActiveCity(city:any,index:any): void {
    this.currentCity = city;
    this.currentIndex = index;
  }
  
}
