module.exports = (sequelize, Sequelize) => {
    const City = sequelize.define("city", {
      cityname: {
        type: Sequelize.STRING
      }
    });
  
    return City;
  };