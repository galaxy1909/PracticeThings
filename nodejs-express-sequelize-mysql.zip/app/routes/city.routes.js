module.exports=app=>{
    const cities=require("../controllers/city.controller.js");
    var router=require("express").Router();
    router.post("/",cities.create);
    router.get("/",cities.findAll);
    router.get("/:id",cities.findOne);
    router.put("/:id",cities.update);
    router.delete("/:id",cities.delete);
    app.use("/api/citys",router);
    
};